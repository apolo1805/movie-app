import './App.css';
import React from 'react';
import ActorsPage from './Pages/ActorsPage/ActorsPage';

function App() {  

  return (
    <div className="app">
      <ActorsPage/>
    </div>
  );
}

export default App;
